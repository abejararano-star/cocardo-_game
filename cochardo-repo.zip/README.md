# Cochardo: La Heladería del Horror

Juego web de terror cómico en pixel art, en un solo archivo HTML (`index.html`). Se juega en el navegador, con teclado o con pantalla táctil, y no necesita instalar nada.

## Dos modos de juego

**Cocardo, el heladero.** Dirige la heladería durante 5 noches: sirve helados, seduce clientes, congélalos en la cámara fría y raspa sus sabores, sin levantar sospechas. Hay clientes VIP, policías encubiertos, inspectores limón, un jefe, escenas entre noches, el detective Banana y 3 finales (uno secreto).

**Banana Negra, el némesis.** Infiltración en 3 niveles con varias salas (salón, cocina y almacén). Busca pistas y llaves que abren puertas, esquiva a Cocardo y las cámaras de seguridad, descongela a las frutas, llévalas a la salida y enfrenta a Cocardo en la pelea final hasta que lo arresta la policía.

## Cómo jugar

Abre `index.html` en el navegador (Chrome, Edge o Firefox) y elige personaje con el mouse en el menú de inicio.

| Acción | Cocardo | Banana |
|---|---|---|
| Mover | WASD | WASD |
| Golpear | ESPACIO | ESPACIO |
| Seducir / Golpe especial | F | F |
| Interactuar | E | E |
| Raspar sabores | R | |
| Correr / Agacharse | | SHIFT / C |
| Lanzar objeto | | G |
| Pausa | P | P (Q sale al título) |

Otras teclas: **M** silencia el sonido y **V** activa o desactiva los efectos visuales. En pantallas táctiles aparecen joystick y botones.

## Jugar en línea con GitHub Pages

1. En el repositorio entra a **Settings → Pages**.
2. En *Build and deployment* elige **Deploy from a branch**, rama `main`, carpeta `/ (root)`.
3. Espera un minuto: el juego quedará en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Cómo está hecho

- Todo el juego vive en `index.html`: la lógica en JavaScript sobre un `<canvas>` de 960x540 y los sprites incrustados en base64.
- Una capa de **PixiJS** (v7.4.2) y **pixi-filters** (v5.3.0), también incluidas en el archivo, añade resplandor, niebla, partículas y ondas. Si el navegador no tiene WebGL, el juego funciona igual sin esos efectos.
- El archivo pesa unos 7 MB.

## Créditos

- Concepto: universo de las "frutinovelas" (Cocardo, Vera/Lima, Cereza, Banana).
- Arte y sprites: generados con IA y recortados para el juego.
- [PixiJS](https://pixijs.com/) y [pixi-filters](https://github.com/pixijs/filters): licencia MIT.

## Licencia

Aún sin definir. Mientras no se agregue un archivo `LICENSE`, todos los derechos quedan reservados.
